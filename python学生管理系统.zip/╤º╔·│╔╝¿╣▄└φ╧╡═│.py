import csv

# 定义学生信息和成绩存储的结构
students = []

def input_student_data():
    student_id = input("请输入学生学号: ")
    name = input("请输入学生姓名: ")
    class_ = input("请输入学生班级: ")
    math = float(input("请输入数学成绩: "))
    english = float(input("请输入英语成绩: "))
    cs = float(input("请输入计算机科学成绩: "))
    student = {
        'student_id': student_id,
        'name': name,
        'class': class_,
        'math': math,
        'english': english,
        'cs': cs
    }
    students.append(student)
    print(f"当前学生数据: {students}")  # 调试信息

def calculate_average_scores():
    total_math = total_english = total_cs = 0
    count = len(students)
    if count == 0:
        print("没有学生数据")
        return
    for student in students:
        total_math += student['math']
        total_english += student['english']
        total_cs += student['cs']
    print(f"数学平均成绩: {total_math / count}")
    print(f"英语平均成绩: {total_english / count}")
    print(f"计算机科学平均成绩: {total_cs / count}")

def query_student_score():
    query = input("请输入学生学号或姓名: ")
    for student in students:
        if student['student_id'] == query or student['name'] == query:
            print(f"学号: {student['student_id']}, 姓名: {student['name']}, 班级: {student['class']}")
            print(f"数学: {student['math']}, 英语: {student['english']}, 计算机科学: {student['cs']}")
            return
    print("未找到该学生")

def rank_by_subject(subject):
    if subject not in ['math', 'english', 'cs']:
        print("无效科目")
        return
    sorted_students = sorted(students, key=lambda x: x[subject], reverse=True)
    for student in sorted_students:
        print(f"学号: {student['student_id']}, 姓名: {student['name']}, {subject.capitalize()}成绩: {student[subject]}")

def save_to_file(filename):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['student_id', 'name', 'class', 'math', 'english', 'cs']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for student in students:
            writer.writerow(student)
            print(f"写入数据: {student}")  # 调试信息
    print(f"数据已保存到 {filename}")

def load_from_file(filename):
    global students
    try:
        with open(filename, 'r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            students = [row for row in reader]
            for student in students:
                student['math'] = float(student['math'])
                student['english'] = float(student['english'])
                student['cs'] = float(student['cs'])
        print(f"数据已从 {filename} 加载")
    except FileNotFoundError:
        print(f"文件 {filename} 未找到")
    except Exception as e:
        print(f"加载数据时出错: {e}")

def main():
    while True:
        print("\n请选择操作:")
        print("1. 录入学生信息和成绩")
        print("2. 计算各科目平均成绩")
        print("3. 查询某学生的成绩")
        print("4. 按某科目成绩进行排名")
        print("5. 从文件读取数据")
        print("6. 退出并保存数据")
        choice = input("请输入选项 (1-6): ")
        
        if choice == '1':
            input_student_data()
        elif choice == '2':
            calculate_average_scores()
        elif choice == '3':
            query_student_score()
        elif choice == '4':
            subject = input("请输入科目 (math, english, cs): ")
            rank_by_subject(subject)
        elif choice == '5':
            filename = input("请输入读取文件名 (包括路径): ")
            load_from_file(filename)
        elif choice == '6':
            break
        else:
            print("无效选择，请重新输入")
    
    # 程序结束时自动保存数据,存储文件地址
    save_to_file("C:\\Users\\86131\\Desktop\\21计科1班.csv")

if __name__ =='__main__':
    main()