里面后缀是ipynb和py的都是代码，你可以把这些合在一起，形成一个总的jpynb文件放在jupyter上面跑
跑出来的形式是html的样式，会生成在本地文件夹，打开就是现象。
注：所有代码均可正常运行，若无法运行请查看您电脑是否正确安装对应的moudle.

其他可能会产生的报错：
TemplateAssertionError                    Traceback (most recent call last)
<ipython-input-14-b5431cdf41d8> in <module>()
    239 
    240 if __name__ == '__main__':
--> 241     first_run()
    242     second_run()
如果出现这个报错表明在 Jinja2 模板引擎渲染模板时遇到了问题。具体来说，模板试图使用一个名为 false 的测试（test），但是 Jinja2 并没有内置名为 false 的测试。
在 Jinja2 中，测试通常用于在模板中执行条件检查。然而，布尔值 false 在 Jinja2 中不需要通过测试来访问，它直接就是一个布尔值。
你可以找到simple_page.html文件，一般在这个路径下：D:\ANACONDA\Lib\site-packages\pyecharts\render\templates
你需要：
将这行代码：{% if chart.remove_br is false %}<br/>{% endif %}
改成：{% if not chart.remove_br %}<br/>{% endif %}
因为：在 Jinja2 中，你应该直接使用 not 关键字来检查一个变量是否不是 true，而不是使用 is false。