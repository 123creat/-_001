import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 关闭交互模式
plt.ioff()

def function1(filename):
    try:
        # 读入文件
        df = pd.read_excel(filename, sheet_name="公式与数", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 剔除治疗方式为空的记录
    df = df.dropna(subset=['治疗方式'])

    # 计算不同治疗方式对应的用药天数的均值
    treatment_means = df.groupby('治疗方式')['用药天数'].mean()
    print("不同治疗方式对应的用药天数的均值:")
    print(treatment_means)
    
    # 统计各种治疗方式的人数
    treatment_counts = df['治疗方式'].value_counts()
    print("各种治疗方式的人数:")
    print(treatment_counts)

def function2(filename):
    try:
        # 读入文件
        df = pd.read_excel(filename, sheet_name="result", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 自定义排序规则，按治疗方式排序
    df_sorted = df.sort_values(by=['治疗方式'], ascending=True)
    
    # 自定义筛选规则，筛选出是否医保为“是”的记录
    df_filtered = df_sorted[df_sorted['医保类型'] == '是']
    
    # 保存结果到result工作表
    with pd.ExcelWriter(filename, mode="a", if_sheet_exists="replace") as writer:
        df_filtered.to_excel(writer, sheet_name="result", index=False)

def function3(filename):
    try:
        # 读入文件，只读取指定的列
        df = pd.read_excel(filename, sheet_name="图表", usecols="C,D", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 检查是否存在 `治疗方式` 和 `用药天数` 列
    if '治疗方式' not in df.columns or '用药天数' not in df.columns:
        print("Error: 必须包含 `治疗方式` 和 `用药天数` 列")
        return
    
    # 小提琴图展示不同治疗方式下的用药天数
    plt.figure(figsize=(10, 6))
    sns.violinplot(x='治疗方式', y='用药天数', data=df, scale='count', inner="quartile", palette="Set2")
    plt.ylabel("用药天数", labelpad=10, fontsize=10)
    plt.xlabel("治疗方式", labelpad=10, fontsize=10)
    plt.title("不同治疗方式下的用药天数分布")
    plt.show()
    
    # 检查是否存在 `医保类型` 列
    if '医保类型' in df.columns:
        # 饼图展示是否医保的人数比例
        insurance_counts = df['医保类型'].value_counts()
        plt.figure(figsize=(8, 8))
        insurance_counts.plot(kind='pie', autopct='%1.1f%%', startangle=140, colors=['#66b3ff','#99ff99'])
        plt.ylabel("")
        plt.title("是否医保的人数比例")
        plt.show()

# 素材地址
filename = "C:\\Users\\86131\\Desktop\\期末课程设计素材_10.xlsx"

# 调用function1
function1(filename)

# 调用function2
function2(filename)

# 调用function3
function3(filename)