import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 关闭交互模式
plt.ioff()

def function1(filename):
    try:
        # 读入文件
        df = pd.read_excel(filename, sheet_name="公式与数", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 剔除手术方式为空的记录
    df = df.dropna(subset=['手术方式'])

    # 计算不同手术方式对应的住院天数的均值
    treatment_means = df.groupby('手术方式')['住院天数'].mean()
    print("不同手术方式对应的住院天数的均值:")
    print(treatment_means)
    
    # 统计各种手术方式的人数
    treatment_counts = df['手术方式'].value_counts()
    print("各种手术方式的人数:")
    print(treatment_counts)

def function2(filename):
    try:
        # 读入文件
        df = pd.read_excel(filename, sheet_name="result", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 自定义排序规则，按手术方式排序
    df_sorted = df.sort_values(by=['手术方式'], ascending=True)
    
    # 自定义筛选规则，筛选出性别为“男”的记录
    df_filtered = df_sorted[df_sorted['性别'] == '男']
    
    # 保存结果到result工作表
    with pd.ExcelWriter(filename, mode="a", if_sheet_exists="replace") as writer:
        df_filtered.to_excel(writer, sheet_name="result", index=False)

def function3(filename):
    try:
        # 读入文件，只读取指定的列
        df = pd.read_excel(filename, sheet_name="图表", usecols="D,E", index_col=False)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    # 检查是否存在 `手术方式` 和 `住院天数` 列
    if '手术方式' not in df.columns or '住院天数' not in df.columns:
        print("Error: 必须包含 `手术方式` 和 `住院天数` 列")
        return
    
    # 小提琴图展示不同手术方式下的住院天数
    plt.figure(figsize=(10, 6))
    sns.violinplot(x='手术方式', y='住院天数', data=df, scale='count', inner="quartile", palette="Set2")
    plt.ylabel("住院天数", labelpad=10, fontsize=10)
    plt.xlabel("手术方式", labelpad=10, fontsize=10)
    plt.title("不同手术方式下的住院天数分布")
    plt.show()
    
    # 检查是否存在 `性别` 列
    if '性别' in df.columns:
        # 饼图展示性别的人数比例
        gender_counts = df['性别'].value_counts()
        plt.figure(figsize=(8, 8))
        gender_counts.plot(kind='pie', autopct='%1.1f%%', startangle=140, colors=['#66b3ff','#99ff99'])
        plt.ylabel("")
        plt.title("性别人数比例")
        plt.show()

# 示例文件名
filename = "C:\\Users\\86131\\Desktop\\期末课程设计素材_12.xlsx"


# 调用function1
function1(filename)

# 调用function2
function2(filename)

# 调用function3
function3(filename)