class Book:
    def __init__(self, title, author, year):
        self.title = title
        self.author = author
        self.year = year

books = []

def add_book():
    title = input("输入书名: ")
    author = input("输入作者: ")
    year = input("输入出版年份: ")
    book = Book(title, author, year)
    books.append(book)
    print("书籍添加成功")

def display_books():
    if not books:
        print("没有书籍")
        return
    for i, book in enumerate(books, 1):
        print(f"{i}. 书名: {book.title}, 作者: {book.author}, 出版年份: {book.year}")

def update_book():
    display_books()
    index = int(input("输入要更新的书籍编号: ")) - 1
    if 0 <= index < len(books):
        title = input("输入新的书名: ")
        author = input("输入新的作者: ")
        year = input("输入新的出版年份: ")
        books[index].title = title
        books[index].author = author
        books[index].year = year
        print("书籍更新成功")
    else:
        print("无效的编号")

def delete_book():
    display_books()
    index = int(input("输入要删除的书籍编号: ")) - 1
    if 0 <= index < len(books):
        books.pop(index)
        print("书籍删除成功")
    else:
        print("无效的编号")

def main():
    while True:
        print("\n图书管理系统")
        print("1. 添加书籍")
        print("2. 显示所有书籍")
        print("3. 更新书籍信息")
        print("4. 删除书籍")
        print("5. 退出系统")
        choice = input("选择操作: ")

        if choice == '1':
            add_book()
        elif choice == '2':
            display_books()
        elif choice == '3':
            update_book()
        elif choice == '4':
            delete_book()
        elif choice == '5':
            print("退出系统")
            break
        else:
            print("无效的选择")

if __name__ == "__main__":
    main()