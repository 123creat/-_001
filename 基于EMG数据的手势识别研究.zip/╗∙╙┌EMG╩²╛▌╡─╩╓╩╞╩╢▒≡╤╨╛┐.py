#注本代码运行对电脑性能要求较高，建议运行时可以减少数据集的量或者分几次运行，写者哔哔（我跑了一个半小时才跑出来）

import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns

# 定义数据文件夹路径
data_folder = "C:\\Users\\86131\\Desktop\\EMG_data_for_gestures-master"  # 替换为实际数据集路径
print(f"Data folder path: {data_folder}")

# 整合所有txt文件中的数据
all_data = []
labels = []

for subdir, _, files in os.walk(data_folder):
    for file in files:
        if file.endswith('.txt'):
            file_path = os.path.join(subdir, file)
            print(f"Reading file: {file_path}")  # 打印文件路径
            try:
                df = pd.read_csv(file_path, sep='\t', header=0)  # 假设第一行是列名
                labels.extend(df['class'])
                all_data.append(df.drop(columns=['time', 'class']))
            except Exception as e:
                print(f"Error reading {file_path}: {e}")

print(f"Total files read: {len(all_data)}")
if len(all_data) == 0:
    raise ValueError("No data read from files. Please check the data folder and file formats.")

# 合并所有数据
combined_data = pd.concat(all_data, ignore_index=True)
print(f"Combined data shape: {combined_data.shape}")

# 数据清洗和特征提取
scaler = StandardScaler()
X_scaled = scaler.fit_transform(combined_data)

# PCA降维到95%的方差解释率
pca = PCA(n_components=0.95)
X_pca = pca.fit_transform(X_scaled)

# 对标签进行编码
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)

# 划分特征(X)和标签(y)
X = X_pca
y = encoded_labels

# 划分数据集为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 初始化随机森林分类器
clf = RandomForestClassifier(random_state=42)

# 使用网格搜索进行超参数优化
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10]
}
grid_search = GridSearchCV(clf, param_grid, cv=5, verbose=2, n_jobs=-1)
grid_search.fit(X_train, y_train)

# 最佳参数
print("最佳参数: ", grid_search.best_params_)

# 使用最佳参数进行训练
best_clf = grid_search.best_estimator_
best_clf.fit(X_train, y_train)

# 预测测试集
y_pred = best_clf.predict(X_test)

# 打印分类报告和混淆矩阵
print(classification_report(y_test, y_pred))
conf_matrix = confusion_matrix(y_test, y_pred)
print(conf_matrix)

# 可视化混淆矩阵
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# 分析哪些因素可以影响手势变化
feature_importances = best_clf.feature_importances_
sorted_indices = np.argsort(feature_importances)[::-1]
top_n = 10  # 显示前10个重要特征
plt.figure(figsize=(12, 6))
plt.bar(range(top_n), feature_importances[sorted_indices][:top_n], align='center')
plt.xticks(range(top_n), combined_data.columns[sorted_indices][:top_n], rotation=90)
plt.xlabel('Feature')
plt.ylabel('Importance')
plt.title('Top 10 Important Features')
plt.show()
