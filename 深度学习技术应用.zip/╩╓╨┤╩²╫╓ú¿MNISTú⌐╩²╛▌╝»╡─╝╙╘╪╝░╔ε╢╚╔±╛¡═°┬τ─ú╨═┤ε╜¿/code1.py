#数据的加载及归一化处理
import tensorflow as tf
from tensorflow.keras.datasets import mnist

# 加载数据集
(x_train, y_train), (x_test, y_test) = mnist.load_data()

# 数据归一化
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# 展开28x28图像为784维向量
x_train = x_train.reshape(-1, 28*28)
x_test = x_test.reshape(-1, 28*28)

# One-hot编码
y_train = tf.keras.utils.to_categorical(y_train, 10)
y_test = tf.keras.utils.to_categorical(y_test, 10)


#全连接层模型搭建
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 搭建全连接层模型
model = Sequential([
    Dense(512, activation='relu', input_shape=(784,)),
    Dense(256, activation='relu'),
    Dense(10, activation='softmax')
])

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# 训练模型
model.fit(x_train, y_train, epochs=10, batch_size=128, validation_split=0.2)

#模型保存
model.save('mnist_model.h5')


#图像识别并呈现
import numpy as np
import matplotlib.pyplot as plt

# 加载模型
model = tf.keras.models.load_model('mnist_model.h5')

# 选择一张测试图片
index = np.random.randint(0, x_test.shape[0])
test_image = x_test[index].reshape(1, 784)
true_label = np.argmax(y_test[index])

# 预测
predicted_label = np.argmax(model.predict(test_image))

# 显示图像和预测结果
plt.imshow(test_image.reshape(28, 28), cmap='gray')
plt.title(f'True Label: {true_label}, Predicted Label: {predicted_label}')
plt.show()