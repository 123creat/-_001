﻿#CIFAR10数据集加载及归一化
import tensorflow as tf
from tensorflow.keras.datasets import cifar10

# 加载数据集
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

# 数据归一化
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# One-hot编码
y_train = tf.keras.utils.to_categorical(y_train, 10)
y_test = tf.keras.utils.to_categorical(y_test, 10)



#经典卷积网络搭建（VGG16）
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Flatten

# 加载VGG16模型，不包括顶层的全连接层
vgg_base = VGG16(weights='imagenet', include_top=False, input_shape=(32, 32, 3))

# 添加自定义顶层
x = Flatten()(vgg_base.output)
x = Dense(256, activation='relu')(x)
x = Dense(10, activation='softmax')(x)

# 创建完整的模型
model = Model(inputs=vgg_base.input, outputs=x)

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# 训练模型
model.fit(x_train, y_train, epochs=10, batch_size=64, validation_split=0.2)

# 保存模型
model.save('cifar10_vgg16_model.h5')

# 加载模型
model = tf.keras.models.load_model('cifar10_vgg16_model.h5')

#图像识别并处理
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.applications.vgg16 import decode_predictions

# 选择一张测试图片
index = np.random.randint(0, x_test.shape[0])
test_image = x_test[index].reshape(1, 32, 32, 3)
true_label = np.argmax(y_test[index])

# 预测
predicted_label = np.argmax(model.predict(test_image))

# CIFAR-10 标签
cifar10_labels = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# 显示图像和预测结果
plt.imshow(test_image.reshape(32, 32, 3))
plt.title(f'True Label: {cifar10_labels[true_label]}, Predicted Label: {cifar10_labels[predicted_label]}')
plt.show()
