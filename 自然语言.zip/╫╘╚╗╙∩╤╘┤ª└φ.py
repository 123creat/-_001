import requests  # 用于发送网络请求
from bs4 import BeautifulSoup  # 用于解析HTML
import re  # 正则表达式库
import jieba  # 中文分词库
import jieba.posseg as pseg  # 词性标注模块
import jieba.analyse  # 关键词提取模块
import concurrent.futures  # 并发执行库

# 获取文章列表的函数
def fetch_articles(query, num_articles=10):
    articles = []
    base_url = "https://scholar.google.com.hk/scholar"
    params = {
        'hl': 'zh-CN',
        'as_sdt': '0,5',
        'q': query,
        'btnG': '',
        'lr': 'lang_zh-CN|lang_zh-TW'
    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    response = requests.get(base_url, headers=headers, params=params)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        links = soup.find_all('h3', class_='gs_rt', limit=num_articles)
        for link in links:
            a_tag = link.find('a')
            if a_tag:
                article_url = a_tag.get('href')
                article_title = a_tag.get_text().strip()
                articles.append((article_title, article_url))
    else:
        print(f"无法获取文章。状态码: {response.status_code}")

    return articles

# 获取文章内容的函数
def fetch_article_text(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        article_text = ""
        paragraphs = soup.find_all('p')
        for paragraph in paragraphs:
            article_text += paragraph.get_text() + "\n"
        return article_text
    except requests.RequestException as e:
        print(f"无法从 {url} 获取文章内容。错误: {e}")
        return ""

# 提取参考文献的函数
def extract_references(article_text):
    references = re.findall(r"参考文献.*?(\d+\..*?)(?=\d+\.|\Z)", article_text, re.S)
    return references

# 中文分词的函数
def segment_text(text):
    seg_list = jieba.cut(text, cut_all=False)
    return " ".join(seg_list)

# 词性标注的函数
def pos_tagging(text):
    words = pseg.cut(text)
    return [(word, flag) for word, flag in words]

# 实体抽取的函数
def extract_entities(text):
    entities = jieba.analyse.extract_tags(text, topK=10, withWeight=False, allowPOS=('ns', 'n', 'vn', 'v'))
    return entities

# 处理文章的函数
def process_article(title, url):
    article_text = fetch_article_text(url)

    if not article_text:
        return

    # 提取参考文献并打印
    references = extract_references(article_text)

    # 进行中文分词并打印结果
    segmented_text = segment_text(article_text)

    # 进行词性标注并打印结果
    pos_tags = pos_tagging(article_text)

    # 进行实体抽取并打印结果
    entities = extract_entities(article_text)

    # 将文章内容保存到txt文件中
    file_path = "./爬取内容.txt"
    
    try:
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(f"文章标题: {title}\n")
            file.write(f"文章URL: {url}\n")
            file.write("文章内容:\n")
            file.write(article_text)
            file.write("\n参考文献:\n")
            for ref in references:
                file.write(ref + "\n")
            file.write("\n分词结果:\n")
            file.write(segmented_text)
            file.write("\n词性标注结果:\n")
            for word, flag in pos_tags:
                file.write(f"{word} - {flag}\n")
            file.write("\n实体抽取结果:\n")
            for entity in entities:
                file.write(entity + "\n")
    except IOError as e:
        print(f"保存文章内容到文件时出错。错误: {e}")

# 主函数
def main():
    query = "自然语言处理"
    num_articles = 5  # 控制要处理的文章数量
    articles = fetch_articles(query, num_articles)

    if not articles:
        print("没有找到相关文章。")
        return

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(process_article, title, url) for title, url in articles]
        for future in concurrent.futures.as_completed(futures):
            future.result()

if __name__ == "__main__":
    main()
